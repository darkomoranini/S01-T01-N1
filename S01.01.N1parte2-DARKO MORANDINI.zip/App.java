
public class App {

	public static void main(String[] args) {
		//Coche coche=new Coche(1200);
		//System.out.println(coche.acelerar());
		//Coche coche1=new Coche(800);
		//System.out.println(coche1.acelerar());
		//System.out.println(Coche.modelo+="-02");
		//System.out.println(Coche.frenar());
		//System.out.println(Coche.marca);
		//System.out.println(Coche.modelo);		
	}
}
