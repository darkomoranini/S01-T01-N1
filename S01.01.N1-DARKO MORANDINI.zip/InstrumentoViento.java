
public class InstrumentoViento extends Instrumento {

	public InstrumentoViento(String name, int price) {
		super(name, price);
	}
	public String tocar() {
		return super.tocar()+"..a wind instrument";
	}
}
