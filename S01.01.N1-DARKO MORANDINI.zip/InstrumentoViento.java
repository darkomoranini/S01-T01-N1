
public class InstrumentoViento extends Instrumento {

	public InstrumentoViento(String name, int price) {
		super(name, price);
	}
	@Override public String tocar() {
		return super.tocar()+"..a wind instrument";
	}
}
