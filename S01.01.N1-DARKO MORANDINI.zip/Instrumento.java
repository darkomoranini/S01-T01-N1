
public class Instrumento {
	protected String name;
	protected int price;
	//static int prueba=10;
	/*static{
		System.out.println("static block 1");
    }*/
	/*{
		System.out.println("initialization block");
	}
	/*static{
		System.out.println("static block 2");
	}
	*/
	public Instrumento(String name, int price) {
		this.name=name;
		this.price=price;
	}
	public void setName(String name) {
		this.name=name;
	}
	public void setPrice(int price) {
		this.price=price;
	}
	public String getName() {
		return name;
	}
	public int getPrice() {
		return price;
	}
	public String tocar() {
		return "Someone is playing..";
	}
}
