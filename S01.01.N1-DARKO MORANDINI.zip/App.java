
public class App {

	public static void main(String[] Args) {
		//InstrumentoCuerda instrument=new InstrumentoCuerda("Guitar", 100);
		//System.out.println(instrument.tocar());
		//System.out.println("main");
		//Instrumento.prueba ++;
	}	
}
