
public class InstrumentoCuerda extends Instrumento {

	public InstrumentoCuerda(String name, int price) {
		super(name, price);
	}
	public String tocar() {
		return super.tocar()+"..a string instrument";
	}
}
