
public class Coche {
	static final String marca="Ferrari";
	static String modelo="F1";
	private final int potencia;
	
	public Coche(int potencia) {
		this.potencia=potencia;	
	}
	public int getPotencia() {
		return potencia;
	}
	static String frenar() {
		return "El coche está frenando";
	}
	public String acelerar() {
		return "El coche está acelarando";
	}
}
